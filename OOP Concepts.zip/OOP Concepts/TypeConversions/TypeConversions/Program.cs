﻿using System;

namespace TypeConversions
{
    class Program
    {
        //TypeCasting, Convert, Parse, TryParse
        public int IntNum = 589;
        public float FloatNum = 586.32f;
        public double DoubleNum = 54.214587;
        public decimal DecimalNum = 89.2547136589m;

        public object Obj = 145;
        public string StrValue = "123";
        static void Main(string[] args)
        {

            Program Pro = new Program();
            //TypeCasting
            Console.WriteLine(Pro.IntNum);
            Console.WriteLine(Pro.FloatNum);
            Console.WriteLine(Pro.DoubleNum);
            Console.WriteLine(Pro.DecimalNum);
            Console.WriteLine(Pro.StrValue);
            Console.WriteLine(Pro.Obj);

            int value1 = (int)Pro.FloatNum;
            Console.WriteLine("Float converted to int: " + value1);
            float value2 = (float)Pro.IntNum;
            Console.WriteLine("Int converted to float: " + value2);

            //Parsing
            //Through parse, we cannot convert a null value to any other type

            Console.WriteLine("String value: " + Pro.StrValue);
            //A string datatype can be converted to an int through parse only if the string is a numeric string.
            //Example: If the string is "Siddharth", it cannot be converted to an int datatype.
            Console.WriteLine("String Converted to Int: " + Int32.Parse(Pro.StrValue));

            //Convert
            //unlike parse, 'Convert' can convert a null value to zero.
            Console.WriteLine("String Converted to int using 'convert': " + Convert.ToInt32(Pro.StrValue));

            Pro.StrValue = null;
            Console.WriteLine("String value 'null' converted to zero through Convert: " + Convert.ToInt32(Pro.StrValue));
        }
    }
}