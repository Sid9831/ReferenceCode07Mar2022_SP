﻿using System;

namespace OOPS
{
    class ClassObjectDemo
    {
        public int a;

        public void DemoFunction()
        {
            Console.WriteLine("This is a method of class ClassObjectDemo");
        }
    }

    class EncapsulationDemo
    {
        int a = 10;
        public int b = 20;
        protected int c = 30;

        public void EncapDemoFunc()
        {
            Console.WriteLine("This function can access private var 'a' as it is part of same class: " + a);
        }

    }

    class EncapsulationChild:EncapsulationDemo
    {
        public void DemoFunction()
        {
            Console.WriteLine("The value of c is " + c);
        }
    }

    class EncapIndirectClassChild : EncapsulationChild
    {
        public void IndirectChild()
        {
            Console.WriteLine("Value of b is " + b);
        }
    }

    class FunctionOverloading
    {
        public void Function1()
        {
            Console.WriteLine("No Parameter, No return type");
        }

        public void Function1(int a)
        {
            Console.WriteLine("One int parameter, no return type");
        }

        public void Function1(int a, int b)
        {
            Console.WriteLine("Two int params, no return type");
        }

        public void Function1(string a)
        {
            Console.WriteLine("One string param, no return type");
        }
    }

    // TYPES OF CLASSES

    //STATIC CLASS
    // All the variables and methods of a static class must also be static.
    static class StaticClass
    {
        public static int a;

        public static void StaticFunction()
        {
            Console.WriteLine("The value of static variable 'a' is " + a);
        }
    }

    //SEALED CLASS
    //The sealed keyword is used to restrict the user from inheriting that class. In other words, a sealed class cannot be inherited. 
    //You can derive a child class from another class and make it a sealed class as well.
    sealed class SealedClass
    {
        public int a;

        public void SealedFunc()
        {
            Console.WriteLine("Sealed class. Variable a: " + a);
        }
    }

    //PARTIAL CLASS
    //When you want to give two or more classes, same name, you can do that by using the keyword 'partial' before a class 
    partial class PartialClass
    {
        public int a;
    }

    partial class PartialClass
    {
        public int b;

        public void PFunction()
        {
            Console.WriteLine("This is a function of partial class. " + b + " " + a);
        }
    }

    //Like normal classes, partial classes can also be inherited, i.e they can act as a parent.
    class PartialChild :PartialClass
    {
        public int c = 38;

        public void demo()
        {
            Console.WriteLine("value of c " + c);
        }
    }

    //ABSTRACT CLASS

    abstract class AbsClass
    {
        //Abstract function decalration.
        public abstract void Demo();


        public void NormalFunction()
        {
            Console.WriteLine("This is the normal function of AbsClass");
        }
    }

    class AbsChild : AbsClass
    {
        //Abstract function of above abstract class is defined here in child class using override keyword
        public override void Demo()
        {
           Console.WriteLine("Demo function of AbsChild class.");
        }

    }

    //All methods in an interface should be abstract and public. No need to use either of those keywords since they are public 
    //and abstract by default.

    interface I1
    {
        void ABSDemo();
    } 

    class Child1: I1
    {
        void I1.ABSDemo()
        {
            Console.WriteLine("ABSDemo function of Child1 says Helloooo...");
        }

        public void NormalChildFunction()
        {
            Console.WriteLine("Normal Function of Child1 says hellooo...");
        }

        
    }

    //DEPENDENCY INJECTION

    // CONSTRUCTOR INJECTION
    public interface I2
    {
        void Demo();
    }

    class C1 : I2
    {
        void I2.Demo()
        {
            Console.WriteLine("Child Class C1 of I2 says hellooo...!!!");
        }
    }

    class C2 : I2
    {
        void I2.Demo()
        {
            Console.WriteLine("Child Class C2 of I2 says hellooo...!!!");

        }
    }

    class ConstructorInjection
    {
        private I2 _i2;

        public ConstructorInjection(I2 _i2)
        {
            this._i2 = _i2;
        }

        public void Demo()
        {
            _i2.Demo();
        }
        
    }

    //METHOD INJECTION

    interface I3
    {
        void Demo();
    }

    class C4 : I3
    {
        void I3.Demo()
        {
            Console.WriteLine("Child Class C4 of I3 says hellooo...!!!");
        }
    }


    class C5 : I3
    {
        void I3.Demo()
        {
            Console.WriteLine("Child Class C5 of I3 says hellooo...!!!");
        }
    }

    class MethodInjection
    {
        private I3 _i3;

        public void Demo(I3 _i3)
        {
            this._i3 = _i3;
            Console.WriteLine("Method Injection Class");
            _i3.Demo();
        }
    }

    //PROPERTY INJECTION

    interface I4
    {
        void Demo(string message);
    }


    class C6 : I4
    {
        void I4.Demo(string message)
        {
            Console.WriteLine(message);
        }
    }

    class C7 : I4
    {
        void I4.Demo(string message)
        {
            Console.WriteLine(message);
        }
    }

    class PropertyInjection
    {
        private I4 _i4;

        public void Demo(I4 _i4, string message)
        {
            this._i4 = _i4;
            Console.WriteLine("PropertyInjection class.");
            _i4.Demo(message);
        }
    }

    //Enums
    //Used to associate strings with numbers.
    enum Months
    {
        Jan = 31,//If not provided, default initialization will be from 0.
        Feb,
        Mar,
        Apr = 22, 
        May,// This will have an initialization value of 23
        June,
        July,
        August,
        Sep,
        Oct,
        Nove,
        December,

    }

    class Program
    {

        //ReadOnly and Const variables
        //The only difference between const and read only variables is that a readonly variable's value can be changed only through a 
        //constructor.
        const int constantVar = 182;//A const var cannot be changed once initialized.
        readonly int readOnlyvar = 256;

       public Program(int d)
        {
            Console.WriteLine("value of read only variable: " + readOnlyvar);
            readOnlyvar = d;
        }

        //Ref and Out keywords 

        static void Example1(int value)
        {
            Console.WriteLine(value);
            value = 12;
            Console.WriteLine(value);
        }

        static void Example2(ref int value)
        {
            Console.WriteLine(value);
            value = 13;
            Console.WriteLine(value);
        }

        static void Example3(out int value)
        {
            value = 14;
            Console.WriteLine(value);
        }

        static void Main(string[] args)
        {
            ClassObjectDemo P1 = new ClassObjectDemo();
            ClassObjectDemo P2 = P1;
            ClassObjectDemo P3 = new ClassObjectDemo();
            ClassObjectDemo P4 = P3;
            ClassObjectDemo P5 = P4;
            ClassObjectDemo P6 = P5;
            ClassObjectDemo P7 = new ClassObjectDemo();

            P1.a = 12;
            P2.a = 85;
            P3.a = 78;
            P4.a = 15;
            P5.a = 54;
            P6.a = 63;
            P7.a = 51;

            Console.WriteLine("Value of P1.a: " + P1.a);
            Console.WriteLine("Value of P2.a: " + P2.a);
            Console.WriteLine("Value of P3.a: " + P3.a);
            Console.WriteLine("Value of P4.a: " + P4.a);
            Console.WriteLine("Value of P5.a: " + P5.a);
            Console.WriteLine("Value of P6.a: " + P6.a);
            Console.WriteLine("Value of P7.a: " + P7.a);
            P1.DemoFunction();

            EncapsulationDemo Demo = new EncapsulationDemo();
            Console.WriteLine("Var b is public. so it can be accessed from anywhere outside the class " + Demo.b);
            Console.WriteLine("Var c is protected so it can only be accessed by direct child of its class.");

            EncapsulationChild EDirectChild = new EncapsulationChild();
            EDirectChild.DemoFunction();
            EDirectChild.EncapDemoFunc();
            Demo.EncapDemoFunc();


            Console.WriteLine("The grandchild of EncapsulationDemo cannot access protected and private members of EncapsulationDemo");
            Console.WriteLine("But it can acsess the public member.");
            EncapIndirectClassChild IC = new EncapIndirectClassChild();
            IC.IndirectChild();
            IC.EncapDemoFunc();

            FunctionOverloading functionOverloading = new FunctionOverloading();
            functionOverloading.Function1();
            functionOverloading.Function1(2);
            functionOverloading.Function1(2,3);
            functionOverloading.Function1("Hello");

            // No need to create an object for a static class.
            
            StaticClass.a = 44;
            StaticClass.StaticFunction();

            SealedClass sealedClass = new SealedClass();
            sealedClass.a = 44;
            sealedClass.SealedFunc();

            //Partial class child:
            PartialClass partialClass = new PartialClass();
            partialClass.a = 22;
            partialClass.b=54;
            partialClass.PFunction();

            //An Abstract class cannot be instantiated, so we create an object of the child class
            AbsChild abschild = new AbsChild();
            abschild.Demo();
            abschild.NormalFunction();

            //An Interface cannot be instantiated, so we create its reference variable and assign the object of its child class to access the abstract methods
            //Only those methods that are inside the interface can be accessed using its reference variable. It cannot access any normal functions of any of its child class
            
            
            I1 _i1 = new Child1();
            _i1.ABSDemo();
            
            //To access the methods of child class, instantiate that child class and use that to access its methods
            Child1 _child1 = new Child1();
            _child1.NormalChildFunction();

            //Constructor Injection
            ConstructorInjection CI = new ConstructorInjection(new C1());
            CI.Demo();

            ConstructorInjection CI2 = new ConstructorInjection(new C2());
            CI2.Demo();

            //Method Injection
            MethodInjection MI = new MethodInjection();
            MI.Demo(new C4());
            MI.Demo(new C5());


            //Property Injection
            PropertyInjection PI = new PropertyInjection();
            PropertyInjection PI2 = new PropertyInjection();
            PI.Demo(new C6(), "Message - Property Injection Child6");
            PI2.Demo(new C7(), "Message - Property Injection Child7");





            int x = 10;
            int y = 20;
            int z = 30;

            Program.Example1(x);
            Console.WriteLine(x);
            //A ref variable acts same as a pointer.
            Program.Example2(ref y);
            Console.WriteLine(y);
            //The only difference between ref and out is that an out variable need not be initialized
            //whereas it is necessary to initialize a ref variable.
            Program.Example3(out z);
            Console.WriteLine(z);



            //'var' keyword is used the same way it is used in javascript.
            //Once a 'var' variable is initialized, it can only be overwritten by value of same datatype.
            var name = "String";
            name = "Siddharth"; //valid
            //name = 10;//invalid

            //Similarly,
            var number = 20;
            number = 30;//valid
            //number = "Siddharth"//invalid



            //OBJECT DATATYPE
            Object id = 10;
            Object Fname = "Siddharth";
            Object BooleanVal = true;
            Object Gender = 'M';

            Console.WriteLine(id);
            Console.WriteLine(Fname);


            //ARRAYS

            //Integer array

            int[] arr = new int[5] {21, 22, 23, 24, 25};
            for (int i=0; i<5; i++)
            {
                Console.WriteLine(arr[i]);
            }

            //String array

            string[] strarray = new string[] {"Siddharth", "Hitesh", "Kandarp"};
            for (int i=0; i<strarray.Length; i++)
            {
                Console.WriteLine(strarray[i]);
            }
            //Likewise we can create an array of any Datatype

            //Object array

            Object[] OB = new Object[] {true, false, "Siddharth", 38, 'M' };
            for (int i=0; i<OB.Length; i++)
            {
                Console.WriteLine(OB[i]);
            }


            //Multidimensional arary

            int[,] Matrix;
            Matrix = new int[6, 6];

            for(int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    Matrix[i, j] = i * j;
                }
            }


            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 6; j++)
                {
                    Console.WriteLine(Matrix[i,j] + "\t");
                }
            }


            Program Pro = new Program(478);

            Console.WriteLine(Pro.readOnlyvar);
            Console.WriteLine(constantVar);


            Console.WriteLine(Convert.ToInt32(Months.May));


            Console.ReadKey();
        }
    }
}