﻿using System;

namespace MemberModelClassList
{
    class MemberModelClass
    {
        public int Id { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }
        public string Contact { get; set; }
        public char Gender { get; set; }


        public MemberModelClass()
        {

        }
    }
}